var requests = require('../config/requests');
var request = require('request');

module.exports = function (app) {
    var createResponse = function (rsp, err) {
        if (err) {
            return {
                status: "error",
                body: err
            };
        } else if (rsp) {
            return {
                status: "ok",
                body: rsp
            };
        }
    }

    app.get('/', function (req, res) {
        res.end("Stock App Server");
    });

    app.post('/signup', function (req, res) {
        var name = req.body.name;
        var username = req.body.username;
        var password = req.body.password;

        requests.signup(name, username, password, function (found, err) {
            res.send(createResponse(found, err));
        });
    });

    app.post('/signin', function (req, res) {
        var username = req.body.username;
        var password = req.body.password;

        requests.signin(username, password, function (found,err) {
            res.send(createResponse(found, err));
        });
    });

    app.post('/addcompany', function (req, res) {
        var name = req.body.name;
        var symbol = req.body.symbol;
        var username = req.body.username;

        requests.addcompany(name, symbol, username, function (found,err) {
            res.json(createResponse(found, err));
        });
    });

    app.post('/addcompanies', function (req, res) {
        var companies = req.body.companies;
        var username = req.body.username;

        requests.addcompanies(companies, username, function (found,err) {
            res.json(createResponse(found, err));
        });
    });

    app.post('/mycompanies', function (req, res) {
        var username = req.body.username;
        requests.mycompanies(username, function (found, err) {
            res.json(createResponse(found, err));
        });
    });
};
