var request = require('request');

var fs = require("fs");
var opt = require("./../settings.json");
var file = "stockapp.db";
var exists = fs.existsSync(file);
var async = require("async");
var NodeRSA = require("node-rsa");
var uuid = require("node-uuid");
var sqlite3 = require("sqlite3").verbose();

var key = new NodeRSA({
    b: 368
});
key.setOptions({
    'signingScheme': 'sha1'
});

key.generateKeyPair();

key.importKey(opt.publicKey, 'pkcs8-public-pem');
key.importKey(opt.privateKey, 'pkcs1-private-pem');

var db = new sqlite3.Database(file);

if (!exists) {
    console.log("Creating database file...");
    fs.openSync(file, "w");
    db.run("CREATE TABLE USER (NAME TEXT, USERNAME TEXT, PASSWORD TEXT)");
    db.run("CREATE TABLE COMPANY (NAME TEXT, SYMBOL TEXT, MIN REAL, MAX REAL, USER REFERENCES USER(USERNAME))");
    console.log("Done!");
}

var userAlreadyExists = function (username) {
    db.all("SELECT * FROM USER WHERE USERNAME=?", [username], function (err, rows) {
        if (err) {
            return true;
        } else
            return !rows.length == 0;
    });
}

exports.signup = function (name, username, password, callback) {

    if (!userAlreadyExists(username)) {
        var stmt = db.prepare("INSERT INTO USER (NAME,USERNAME,PASSWORD) VALUES ($name, $username, $password)");
        stmt.bind({
            $name: name,
            $username: username,
            $password: password
        });
        stmt.run();
        stmt.finalize();

        callback({
            'response': "OK"
        }, null);
    } else {
        callback(null, {
            'response': "Username already exists"
        });
    }
}

exports.signin = function (username, password, callback) {
    this.users(function (users) {
        var found = 0;

        for (var i = 0; i < users.length; i++) {
            if (users[i].USERNAME == username && users[i].PASSWORD == password)
                found = 1;
        }

        if (found == 1)
            callback({
                'response': "OK"
            }, null);
        else
            callback({
                'response': "Wrong username or password"
            }, null);
    });
}

exports.users = function (callback) {
    db.all("SELECT * FROM USER", function (err, rows) {
        callback(
            rows, null);
    });
}

exports.addcompany = function (name, symbol, min, max, username, callback) {
    var stmt = db.prepare("INSERT INTO COMPANY (NAME,SYMBOL,USER,MIN,MAX) VALUES ($name, $symbol, $username, $min, $max)");
    stmt.bind({
        $name: name,
        $symbol: symbol,
        $min: min,
        $max: max,
        $username: username
    });
    stmt.run();
    stmt.finalize();

    callback({
        response: "OK"
    }, null);
}

exports.addcompanies = function (companies, username, callback) {
    var stmt = db.prepare("DELETE FROM COMPANY WHERE USER=$username");
    stmt.bind({
        $username: username
    });
    stmt.run();
    stmt.finalize();

    for (var i = 0; i < companies.length; i++) {
        var stmt = db.prepare("INSERT INTO COMPANY (NAME,SYMBOL,USER,MIN,MAX) VALUES ($name, $symbol, $username, $min, $max)");
        stmt.bind({
            $name: companies[i].NAME,
            $symbol: companies[i].SYMBOL,
            $min: companies[i].MIN,
            $max: companies[i].MAX,
            $username: username
        });
        stmt.run();
        stmt.finalize();
    }

    callback({
        response: "OK"
    }, null);
}

exports.mycompanies = function (username, callback) {
    db.all("SELECT * FROM COMPANY WHERE USER=?", [username], function (err, rows) {
        if (rows.length == 0) {
            callback({
                response: []
            }, null);

        } else {callback({
            response: rows
        }, null);
        }
    });
}
